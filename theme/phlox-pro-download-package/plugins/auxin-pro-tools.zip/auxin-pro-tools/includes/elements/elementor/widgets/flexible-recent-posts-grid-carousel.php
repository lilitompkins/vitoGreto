<?php
namespace Auxin\Plugin\Pro\Elementor\Elements;

use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Utils;
use Elementor\Control_Media;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}

/**
 * Elementor 'FlexibleRecentPostsGridCarousel' widget.
 *
 * Elementor widget that displays an 'FlexibleRecentPostsGridCarousel' with lightbox.
 *
 * @since 1.0.0
 */
class FlexibleRecentPostsGridCarousel extends Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve 'FlexibleRecentPostsGridCarousel' widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'aux_flexible_recent_posts';
    }

    /**
     * Get widget title.
     *
     * Retrieve 'FlexibleRecentPostsGridCarousel' widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __('Flexible Posts', PLUGIN_DOMAIN );
    }

    /**
     * Get widget icon.
     *
     * Retrieve 'FlexibleRecentPostsGridCarousel' widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-posts-grid auxin-badge';
    }

    /**
     * Get widget categories.
     *
     * Retrieve 'FlexibleRecentPostsGridCarousel' widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_categories() {
        return array( 'auxin-dynamic' );
    }

    /**
     * Retrieve the terms in a given taxonomy or list of taxonomies.
     *
     * Retrieve 'FlexibleRecentPostsGridCarousel' widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_terms() {
        $terms = get_terms( 'category', 'orderby=count&hide_empty=0' );
        $list  = array( ' ' => __('All Categories', PLUGIN_DOMAIN ) ) ;
        foreach ( $terms as $key => $value ) {
            $list[$value->term_id] = $value->name;
        }

        return $list;
    }

    /**
     * Get recent comments.
     *
     * Retrieve 'RecentComments' widget query.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Query.
     */
    public function get_post_types( $args = array()  ) {
        // Result variable
        $result = array();
        // Get all public post types
        $get_post_types = get_post_types( array(
            'public' => true,
            'exclude_from_search' => false
            )
        );
        foreach ( $get_post_types as $key =>  $value ) {
            if( $key === 'attachment '){
                continue;
            }
            // Get all posts of post type
            $posts = get_posts( array(
                'post_type' => $key,
                'post_status' => 'publish',
                'numberposts' => -1
            ));
            // Check post type emptiness
            if( !empty( $posts ) ){
                $result[ $key ] = ucfirst( $key );
            }
        }

        return $result;
    }

    public function get_taxonomy_name(){
        $post_type = $this->get_settings( 'post_type' );
        $post_tax  = $this->get_settings( 'post_type_taxonomy' );
        // Update taxonomy name
        if( !empty( $post_tax ) ){
            return $post_tax;
        } else {
            $object_taxonomies = get_object_taxonomies( $post_type );
            foreach ( $object_taxonomies as $ob_key => $ob_tax ) {
                if( strpos( $ob_tax, 'cat' ) !== false ){
                    return $ob_tax;
                }
            }
        }

        return 'category';
    }

    /**
     * Register 'FlexibleRecentPostsGridCarousel' widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {

        /*-----------------------------------------------------------------------------------*/
        /*  layout_section
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => __('Layout', PLUGIN_DOMAIN ),
                'tab'   => Controls_Manager::TAB_LAYOUT
            )
        );

        // $this->add_control(
        //     'post_type',
        //     array(
        //         'label'       => __( 'Post Type', PLUGIN_DOMAIN ),
        //         'label_block' => true,
        //         'type'        => Controls_Manager::SELECT,
        //         'default'     => 'post',
        //         'options'     => $this->get_post_types()
        //     )
        // );

        // $this->add_control(
        //     'post_type_taxonomy',
        //     array(
        //         'label'       => __( 'Category Slug', PLUGIN_DOMAIN ),
        //         'description' => __( 'We will try to find your current post type. But if we did not succeed, Enter your own category slug in this field.', PLUGIN_DOMAIN ),
        //         'label_block' => true,
        //         'type'        => Controls_Manager::TEXT,
        //         'condition'   => array(
        //             'post_type!' => 'post',
        //         ),
        //         'default'     => ''
        //     )
        // );

        $this->add_control(
            'post_column',
            array(
                'label'          => __( 'Select Post Column', PLUGIN_DOMAIN ),
                'type'           => Controls_Manager::SELECT,
                'default'        => ' ',
                'options'        => auxin_get_elementor_templates_list('single')
            )
        );

        $this->add_responsive_control(
            'columns',
            array(
                'label'          => __( 'Columns', PLUGIN_DOMAIN ),
                'type'           => Controls_Manager::SELECT,
                'default'        => '4',
                'tablet_default' => 'inherit',
                'mobile_default' => '1',
                'options'        => array(
                    'inherit' => __( 'Inherited from larger', PLUGIN_DOMAIN ),
                    '1'       => '1',
                    '2'       => '2',
                    '3'       => '3',
                    '4'       => '4',
                    '5'       => '5',
                    '6'       => '6'
                ),
                'frontend_available' => true,
            )
        );

        $this->add_control(
            'preview_mode',
            array(
                'label'       => __('Display items as', PLUGIN_DOMAIN),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'grid',
                'options'     => array(
                    'grid'            => __( 'Grid', PLUGIN_DOMAIN ),
                    'carousel'        => __( 'Carousel', PLUGIN_DOMAIN )
                )
            )
        );

        $this->add_control(
            'carousel_space',
            array(
                'label'       => __( 'Column space', PLUGIN_DOMAIN ),
                'description' => __( 'Specifies space between carousel columns in pixels.', PLUGIN_DOMAIN ),
                'type'        => Controls_Manager::NUMBER,
                'default'     => '25',
                'condition'   => array(
                    'preview_mode' => array( 'carousel', 'carousel-modern' ),
                )
            )
        );

        $this->add_control(
            'carousel_navigation',
            array(
                'label'       => __('Navigation type', PLUGIN_DOMAIN),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'peritem',
                'options'     => array(
                   'peritem' => __('Move per column', PLUGIN_DOMAIN),
                   'perpage' => __('Move per page', PLUGIN_DOMAIN),
                   'scroll'  => __('Smooth scroll', PLUGIN_DOMAIN)
                ),
                'condition'   => array(
                    'preview_mode' => array( 'carousel', 'carousel-modern' ),
                )
            )
        );

        $this->add_control(
            'carousel_navigation_control',
            array(
                'label'       => __('Navigation control', PLUGIN_DOMAIN),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'bullets',
                'options'     => array(
                    ''        => __('None', PLUGIN_DOMAIN),
                    'arrows'  => __('Arrows', PLUGIN_DOMAIN),
                    'bullets' => __('Bullets', PLUGIN_DOMAIN)
                ),
                'condition'   => array(
                    'preview_mode' => array( 'carousel', 'carousel-modern' ),
                )
            )
        );

        $this->add_control(
            'carousel_nav_control_pos',
            array(
                'label'       => __('Control Position', PLUGIN_DOMAIN),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'center',
                'options'     => array(
                   'center'         => __('Center', PLUGIN_DOMAIN),
                   'side'           => __('Side', PLUGIN_DOMAIN)
                ),
                'condition'   => array(
                    'carousel_navigation_control' => 'arrows',
                )
            )
        );

        $this->add_control(
            'carousel_nav_control_skin',
            array(
                'label'       => __('Control Skin', PLUGIN_DOMAIN),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'boxed',
                'options'     => array(
                   'boxed' => __('boxed', PLUGIN_DOMAIN),
                   'long'  => __('Long Arrow', PLUGIN_DOMAIN)
                ),
                'condition'   => array(
                    'carousel_navigation_control' => 'arrows',
                )
            )
        );

        $this->add_control(
            'carousel_loop',
            array(
                'label'        => __('Loop navigation',PLUGIN_DOMAIN ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'On', PLUGIN_DOMAIN ),
                'label_off'    => __( 'Off', PLUGIN_DOMAIN ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'   => array(
                    'preview_mode' => array( 'carousel', 'carousel-modern' ),
                )
            )
        );

        $this->add_control(
            'carousel_autoplay',
            array(
                'label'        => __('Autoplay carousel',PLUGIN_DOMAIN ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'On', PLUGIN_DOMAIN ),
                'label_off'    => __( 'Off', PLUGIN_DOMAIN ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'   => array(
                    'preview_mode' => array( 'carousel', 'carousel-modern' ),
                )
            )
        );

        $this->add_control(
            'carousel_autoplay_delay',
            array(
                'label'       => __( 'Autoplay delay', PLUGIN_DOMAIN ),
                'description' => __('Specifies the delay between auto-forwarding in seconds.', PLUGIN_DOMAIN ),
                'type'        => Controls_Manager::NUMBER,
                'default'     => '2',
                'condition'   => array(
                    'preview_mode' => array( 'carousel', 'carousel-modern' ),
                )
            )
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  query_section
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'query_section',
            array(
                'label'      => __('Query', PLUGIN_DOMAIN ),
            )
        );

		// $this->add_group_control(
		// 	Group_Control_Posts::get_type(),
		// 	[
		// 		'name' => 'posts',
		// 	]
		// );

        $this->add_control(
            'cat',
            array(
                'label'       => __('Categories', PLUGIN_DOMAIN),
                'description' => __('Specifies a category that you want to show posts from it.', PLUGIN_DOMAIN ),
                'type'        => Controls_Manager::SELECT2,
                'multiple'    => true,
                'options'     => $this->get_terms(),
                'default'     => array( ' ' ),
            )
        );

        $this->add_control(
            'num',
            array(
                'label'       => __('Number of posts to show', PLUGIN_DOMAIN),
                'label_block' => true,
                'type'        => Controls_Manager::NUMBER,
                'default'     => '8',
                'min'         => 1,
                'step'        => 1
            )
        );

        $this->add_control(
            'exclude_without_media',
            array(
                'label'        => __('Exclude posts without media',PLUGIN_DOMAIN ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'On', PLUGIN_DOMAIN ),
                'label_off'    => __( 'Off', PLUGIN_DOMAIN ),
                'return_value' => 'yes',
                'default'      => 'no'
            )
        );

        $this->add_control(
            'exclude_custom_post_formats',
            array(
                'label'        => __('Exclude all custom post formats',PLUGIN_DOMAIN ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'On', PLUGIN_DOMAIN ),
                'label_off'    => __( 'Off', PLUGIN_DOMAIN ),
                'return_value' => 'yes',
                'default'      => 'no',
            )
        );

        $this->add_control(
            'include_post_formats_in',
            array(
                'label'       => __('Include custom post formats', PLUGIN_DOMAIN),
                'type'        => Controls_Manager::SELECT2,
                'multiple'    => true,
                'options'     => array(
                    'aside'    => __('Aside', PLUGIN_DOMAIN),
                    'gallery'  => __('Gallery', PLUGIN_DOMAIN),
                    'image'    => __('Image', PLUGIN_DOMAIN),
                    'link'     => __('Link', PLUGIN_DOMAIN),
                    'quote'    => __('Quote', PLUGIN_DOMAIN),
                    'video'    => __('Video', PLUGIN_DOMAIN),
                    'audio'    => __('Audio', PLUGIN_DOMAIN)
                ),
                'condition'    => array(
                    'exclude_custom_post_formats!' => 'yes',
                )
            )
        );

        $this->add_control(
            'exclude_quote_link',
            array(
                'label'        => __('Exclude quote and link post formats',PLUGIN_DOMAIN ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'On', PLUGIN_DOMAIN ),
                'label_off'    => __( 'Off', PLUGIN_DOMAIN ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => array(
                    'exclude_custom_post_formats' => 'yes',
                )
            )
        );


        $this->add_control(
            'order_by',
            array(
                'label'       => __('Order by', PLUGIN_DOMAIN),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'date',
                'options'     => array(
                    'date'            => __('Date', PLUGIN_DOMAIN),
                    'menu_order date' => __('Menu Order', PLUGIN_DOMAIN),
                    'title'           => __('Title', PLUGIN_DOMAIN),
                    'ID'              => __('ID', PLUGIN_DOMAIN),
                    'rand'            => __('Random', PLUGIN_DOMAIN),
                    'comment_count'   => __('Comments', PLUGIN_DOMAIN),
                    'modified'        => __('Date Modified', PLUGIN_DOMAIN),
                    'author'          => __('Author', PLUGIN_DOMAIN),
                    'post__in'        => __('Inserted Post IDs', PLUGIN_DOMAIN)
                ),
            )
        );

        $this->add_control(
            'order',
            array(
                'label'       => __('Order', PLUGIN_DOMAIN),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'DESC',
                'options'     => array(
                    'DESC'          => __('Descending', PLUGIN_DOMAIN),
                    'ASC'           => __('Ascending', PLUGIN_DOMAIN),
                ),
            )
        );

        $this->add_control(
            'only_posts__in',
            array(
                'label'       => __('Only posts',PLUGIN_DOMAIN ),
                'description' => __('If you intend to display ONLY specific posts, you should specify the posts here. You have to insert the post IDs that are separated by comma (eg. 53,34,87,25).', PLUGIN_DOMAIN ),
                'type'        => Controls_Manager::TEXT
            )
        );

        $this->add_control(
            'include',
            array(
                'label'       => __('Include posts',PLUGIN_DOMAIN ),
                'description' => __('If you intend to include additional posts, you should specify the posts here. You have to insert the Post IDs that are separated by comma (eg. 53,34,87,25)', PLUGIN_DOMAIN ),
                'type'        => Controls_Manager::TEXT
            )
        );

        $this->add_control(
            'exclude',
            array(
                'label'       => __('Exclude posts',PLUGIN_DOMAIN ),
                'description' => __('If you intend to exclude specific posts from result, you should specify the posts here. You have to insert the Post IDs that are separated by comma (eg. 53,34,87,25)', PLUGIN_DOMAIN ),
                'type'        => Controls_Manager::TEXT
            )
        );

        $this->add_control(
            'offset',
            array(
                'label'       => __('Start offset',PLUGIN_DOMAIN ),
                'description' => __('Number of post to displace or pass over.', PLUGIN_DOMAIN ),
                'type'        => Controls_Manager::NUMBER
            )
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  paginate_section
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'paginate_section',
            array(
                'label'      => __('Paginate', PLUGIN_DOMAIN ),
            )
        );

        $this->add_control(
            'loadmore_type',
            array(
                'label'       => __('Load More Type',PLUGIN_DOMAIN ),
                'type'        => 'aux-visual-select',
                'options'     => array(
                    ''       => array(
                        'label' => __('None', PLUGIN_DOMAIN ),
                        'image' => AUXIN_URL . 'images/visual-select/load-more-none.svg'
                    ),
                    'scroll' => array(
                        'label' => __('Infinite Scroll', PLUGIN_DOMAIN ),
                        'image' => AUXIN_URL . 'images/visual-select/load-more-infinite.svg'
                    ),
                    'next'   => array(
                        'label' => __('Next Button', PLUGIN_DOMAIN ),
                        'image' => AUXIN_URL . 'images/visual-select/load-more-button.svg'
                    ),
                    'next-prev'  => array(
                        'label' => __('Next Prev', PLUGIN_DOMAIN ),
                        'image' => AUXIN_URL . 'images/visual-select/load-more-next-prev.svg'
                    )
                ),
                'default'     => ''
            )
        );

        $this->end_controls_section();

    }

  /**
   * Render image box widget output on the frontend.
   *
   * Written in PHP and used to generate the final HTML.
   *
   * @since 1.0.0
   * @access protected
   */
  protected function render() {
    $settings = $this->get_settings_for_display();

    // Defining default attributes
    $default_atts = array(
        'cat'                         => ' ',
        'num'                         => '8',   // max generated entry
        'only_posts__in'               => '',   // display only these post IDs. array or string comma separated
        'include'                     => '',    // include these post IDs in result too. array or string comma separated
        'exclude'                     => '',    // exclude these post IDs from result. array or string comma separated
        'offset'                      => '',
        'paged'                       => '',
        'post_type'                   => 'post',
        'taxonomy_name'               => 'category', // the taxonomy that we intent to display in post info
        'order_by'                    => 'date',
        'order'                       => 'DESC',
        'preview_mode'                => 'grid',

        'exclude_without_media'       => 0,
        'exclude_custom_post_formats' => 0,
        'exclude_quote_link'          => 0,
        'include_post_formats_in'     => array(), // the list od post formats to exclude
        'exclude_post_formats_in'     => array(), // the list od post formats to exclude

        'post_column'                 => '',
        'columns'                     => 4,
        'columns_tablet'              => 'inherit',
        'columns_mobile'              => '1',
        'extra_classes'               => '',
        'extra_column_classes'        => '',
        'custom_el_id'                => '',
        'carousel_space'              => '30',
        'carousel_autoplay'           => false,
        'carousel_autoplay_delay'     => '2',
        'carousel_navigation'         => 'peritem',
        'carousel_navigation_control' => 'arrows',
        'carousel_nav_control_pos'    => 'center',
        'carousel_nav_control_skin'   => 'boxed',
        'carousel_loop'               => 1,
        'request_from'                => '',

        'universal_id'                => '',
        'use_wp_query'                => false, // true to use the global wp_query, false to use internal custom query
        'reset_query'                 => true,
        'wp_query_args'               => array(), // additional wp_query args
        'custom_wp_query'             => '',
        'loadmore_type'               => '', // 'next' (more button), 'scroll', 'next-prev'
        'loadmore_per_page'           => '',
        'base'                        => 'aux_flexible_recent_posts',
        'base_class'                  => 'aux-widget-flexible-recent-posts'
    );

    $result = auxin_get_widget_scafold( $settings, $default_atts, NULL );
    extract( $result['parsed_atts'] );

    // Exclude post formats
    if( $exclude_custom_post_formats ){
        $exclude_post_formats_in = array_merge( $exclude_post_formats_in, array( 'aside', 'gallery', 'image', 'link', 'quote', 'video', 'audio' ) );
    }
    if( $exclude_quote_link ){
        $exclude_post_formats_in[] = 'quote';
        $exclude_post_formats_in[] = 'link';
    }
    $exclude_post_formats_in = array_unique( $exclude_post_formats_in );

    // Update taxonomy name
    if( $post_type !== 'post' ){
        $taxonomy_name = $this->get_taxonomy_name();
    }

    // Set category taxonomy
    $tax_args = array();
    if( ! empty( $cat ) && $cat != " " && ( ! is_array( $cat ) || ! in_array( " ", $cat ) ) ) {
        $tax_args = array(
            array(
                'taxonomy' => $taxonomy_name,
                'field'    => 'term_id',
                'terms'    => ! is_array( $cat ) ? explode( ",", $cat ) : $cat
            )
        );
    }

    if( ! $use_wp_query ){

        // create wp_query to get latest items ---------------------------------
        $args = array(
            'post_type'               => $post_type,
            'orderby'                 => $order_by,
            'order'                   => $order,
            'offset'                  => $offset,
            'paged'                   => $paged,
            'tax_query'               => $tax_args,
            'post_status'             => 'publish',
            'posts_per_page'          => $num,
            'ignore_sticky_posts'     => 1,

            'include_posts__in'       => $include, // include posts in this list
            'posts__not_in'           => $exclude, // exclude posts in this list
            'posts__in'               => $only_posts__in, // only posts in this list

            'exclude_without_media'   => auxin_is_true( $exclude_without_media ),
            'exclude_post_formats_in' => $exclude_post_formats_in,
            'include_post_formats_in' => $include_post_formats_in
        );

        // ---------------------------------------------------------------------

        // add the additional query args if available
        if( $wp_query_args ){
            $args = wp_parse_args( $wp_query_args, $args );
        }

        // pass the args through the auxin query parser
        $wp_query = new \WP_Query( auxin_parse_query_args( $args ) );
    } else {
        global $wp_query;
    }


    // widget header ------------------------------
    echo $result['widget_header'];
    echo $result['widget_title'];

    $phone_break_point     = 767;
    $tablet_break_point    = 992;

    $column_class          = '';
    $item_class            = 'aux-col';
    $carousel_attrs        = '';

    $columns_custom_styles = '';

    if( ! empty( $loadmore_type ) ) {
        $item_class        .= ' aux-ajax-item';
    }

    $columns_tablet  = ('inherit' == $columns_tablet ) ? $columns : $columns_tablet;
    $columns_mobile   = ('inherit' == $columns_mobile  )  ? $columns_tablet : $columns_mobile;

    if ( $preview_mode === 'grid' ) {
        // generate columns class
        $column_class  = 'aux-row aux-de-col' . $columns;

        $column_class .=  ' aux-tb-col'.$columns_tablet . ' aux-mb-col'.$columns_mobile;

    } elseif ( $preview_mode === 'carousel' ) {
        $column_class    = 'master-carousel aux-no-js aux-mc-before-init' . ' aux-' . $carousel_nav_control_pos . '-control';
        $item_class      = 'aux-mc-item';

        // genereate the master carousel attributes
        $carousel_attrs  =  'data-columns="' . esc_attr( $columns ) . '"';
        $carousel_attrs .= auxin_is_true( $carousel_autoplay ) ? ' data-autoplay="true"' : '';
        $carousel_attrs .= auxin_is_true( $carousel_autoplay ) ? ' data-delay="' . esc_attr( $carousel_autoplay_delay ) . '"' : '';
        $carousel_attrs .= ' data-navigation="' . esc_attr( $carousel_navigation ) . '"';
        $carousel_attrs .= ' data-space="' . esc_attr( $carousel_space ). '"';
        $carousel_attrs .= auxin_is_true( $carousel_loop ) ? ' data-loop="' . esc_attr( $carousel_loop ) . '"' : '';
        $carousel_attrs .= ' data-wrap-controls="true"';
        $carousel_attrs .= ' data-bullets="' . ('bullets' == $carousel_navigation_control ? 'true' : 'false') . '"';
        $carousel_attrs .= ' data-bullet-class="aux-bullets aux-small aux-mask"';
        $carousel_attrs .= ' data-arrows="' . ('arrows' == $carousel_navigation_control ? 'true' : 'false') . '"';
        $carousel_attrs .= ' data-same-height="true"';

        if ( 'inherit' != $columns_tablet || 'inherit' != $columns_mobile ) {
            $carousel_attrs .= ' data-responsive="'. esc_attr( ( 'inherit' != $columns_tablet  ? $tablet_break_point . ':' . $columns_tablet . ',' : '' ).
                                                               ( 'inherit' != $columns_mobile   ? $phone_break_point  . ':' . $columns_mobile : '' ) ) . '"';
        }

    }

    // Specifies whether the columns have footer meta or not
    $column_class  .= ' aux-ajax-view  ' . $extra_column_classes;

    $have_posts = $wp_query->have_posts();

    if( $have_posts ){

        echo ! $skip_wrappers ? sprintf( '<div data-element-id="%s" class="%s" %s>', esc_attr( $universal_id ), esc_attr( $column_class ), $carousel_attrs ) : '';

        while ( $wp_query->have_posts() ) {

            $wp_query->the_post();
            $post = get_post();
            // add specific class to current classes for each column
            $post_classes  = 'post column-entry';

            if( ! empty( $post_column ) || $post_column !== ' ' ){
                printf( '<div class="%s post-%s">', esc_attr( $item_class ), esc_attr( $post->ID ) );
                auxpro_get_post_column_template( $post_column, $post_classes );
                echo '</div>';
            }

        }


        if ( $preview_mode === 'carousel' && 'arrows' == $carousel_navigation_control ) {
            if ( 'boxed' === $carousel_nav_control_skin ) :?>
                <div class="aux-carousel-controls">
                    <div class="aux-next-arrow aux-arrow-nav aux-outline aux-hover-fill">
                        <span class="aux-svg-arrow aux-small-right"></span>
                        <span class="aux-hover-arrow aux-white aux-svg-arrow aux-small-right"></span>
                    </div>
                    <div class="aux-prev-arrow aux-arrow-nav aux-outline aux-hover-fill">
                        <span class="aux-svg-arrow aux-small-left"></span>
                        <span class="aux-hover-arrow aux-white aux-svg-arrow aux-small-left"></span>
                    </div>
                </div>
            <?php else : ?>
                <div class="aux-carousel-controls">
                    <div class="aux-next-arrow">
                        <span class="aux-svg-arrow aux-l-right"></span>
                    </div>
                    <div class="aux-prev-arrow">
                        <span class="aux-svg-arrow aux-l-left"></span>

                    </div>
                </div>
            <?php  endif;
        }

        if( ! $skip_wrappers ) {
            // End tag for aux-ajax-view wrapper
            echo '</div>';
            // Execute load more functionality
            if( $preview_mode !== 'carousel' && $wp_query->found_posts > $loadmore_per_page ) {
                echo auxin_get_load_more_controller( $loadmore_type );
            }

        } else {
            // Get post counter in the query
            echo '<span class="aux-post-count hidden">'.$wp_query->post_count.'</span>';
        }

    }


    if( $reset_query ){
        wp_reset_postdata();
    }

    // return false if no result found
    if( ! $have_posts ){
        ob_get_clean();
        return false;
    }

    // widget footer ------------------------------
    echo $result['widget_footer'];

  }

}
