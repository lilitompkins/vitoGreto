<?php 

// Add metaboxes for product
include_once( 'metabox-fields-product.php' );