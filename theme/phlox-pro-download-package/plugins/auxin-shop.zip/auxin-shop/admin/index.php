<?php

include( 'includes/metaboxes/index.php' );
include( 'includes/admin-hooks.php' );