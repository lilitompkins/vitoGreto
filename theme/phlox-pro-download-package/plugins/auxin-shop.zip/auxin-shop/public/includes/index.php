<?php 

include 'classes/class-auxshp-frontend-assets.php';
include 'classes/class-auxshp-template-loader.php';