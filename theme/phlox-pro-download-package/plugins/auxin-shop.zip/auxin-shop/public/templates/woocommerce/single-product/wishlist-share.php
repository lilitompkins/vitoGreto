<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<div class="auxshp-sw-wrapper">
    <?php do_action( 'auxshp_share_section' ); ?>
</div>

