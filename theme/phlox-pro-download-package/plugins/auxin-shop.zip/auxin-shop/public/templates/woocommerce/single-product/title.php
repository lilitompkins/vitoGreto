<?php
/**
 * CHanges: h2 used instead of h1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

the_title( '<h2 class="product_title entry-title">', '</h2>' );
