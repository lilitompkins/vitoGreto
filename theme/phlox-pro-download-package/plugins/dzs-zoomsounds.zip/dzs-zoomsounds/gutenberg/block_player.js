/**
 * Block dependencies
 */

// import classnames from 'classnames'; 2

/**
 * Internal block libraries
 */


let __ = (arg)=>{return arg;};

if(wp.i18n){
  __ = wp.i18n.__;
}

const { registerBlockType } = wp.blocks;

const {
  RichText,
  InspectorControls,
  BlockControls,
  MediaUpload
} = wp.editor;

const {
  PanelBody,
  TextareaControl,
  TextControl,
  Dashicon,
  SelectControl,
  Toolbar,
  Button,
  Tooltip,
} = wp.components;

/**
 * Register block
 */

const player_controls = [];
let arr_options = [];
let player_inspector_controls = null;
let player_attributes = {
  text_string: {
    type: 'string',
  },
  tweet: {
    type: 'string',
  },
  tweetsent: {
    type: 'string',
  },
  button: {
    type: 'string',
    default: 'button',
  },
  theme: {
    type: 'boolean',
    default: false,
  },
  backgroundimage: {
    type: 'string',
    default: null, // no image by default!
  }
};
window.onload = function() {



  try{
    arr_options = JSON.parse(window.dzsap_settings.player_options);
  }catch(err){
    console.info('err - ',err,window.dzsap_settings.player_options);

  }
  console.info('arr_options_player - ',arr_options);


  // arr_options.forEach(function(el4,ind) {
  //   console.info('el4 - ', el4);
  // })
  // console.info('player_controls- ',player_controls);

  arr_options.forEach((el) => {



    let aux = {};

    aux.type = 'string';
    if((el.type)) {
      aux.type = el.type;
    }
    if((el['default'])){

      aux['default'] = el['default'];
    }

    // -- sanitizing
    if(aux.type=='text'){
      aux.type='string';
    }

    // console.log('aux.type - ',aux.type);

    if(aux.type=='string'){
      player_attributes[el.name] = aux;
    }

  })

};


// console.info('player_attributes - ',player_attributes);
console.info('window.dzsvg_gutenberg_player_options_for_js_init - ',window.dzsap_gutenberg_player_options_for_js_init);

export default registerBlockType( 'dzsap/gutenberg-player', {
  // Block Title
  title: 'ZoomSounds ' + __( 'Player' ),
  // Block Description
  description: __( 'Powerful audio player' ),
  // Block Category
  category: 'common',
  // Block Icon
  icon: 'format-audio',
  // Block Keywords
  keywords: [
    __( 'Audio player' ),
    __( 'Sound' ),
    __( 'Song' ),
  ],
  attributes: window.dzsap_gutenberg_player_options_for_js_init,
  // Defining the edit interface
  edit: props => {
    const {
      attributes
    } = props;
    let {backgroundimage} = attributes;
    const onChangeText = (e) => {
      console.info('e - ',e);
    }
    const onChangeTweet = value => {
      props.setAttributes( { artistname: value } );
    };
    const onChangeTweetSent = value => {
      props.setAttributes( { tweetsent: value } );
    };
    const onChangeButton = value => {
      props.setAttributes( { button: value } );
    };
    const toggletheme = value => {
      props.setAttributes( { theme: !props.attributes.theme } );
    };
    const ALLOWED_MEDIA_TYPES = [ 'audio' ];


    function onTextChange(changes) {
      props.setAttributes({
        text_string: changes
      });
    }

    function onValueChange(value,arg2){

      console.info('value - ',value,arg2);
      // props.setAttributes({[el4.name]: value});
      // console.info('new props - ',props);
    }


    // console.log('lets wee what props we have',props);

    let uploadButtonLabel = __('Upload');

    if(props.attributes.dzsap_meta_item_source || props.attributes.source){
      uploadButtonLabel = __('Select another upload');
    }

    let uploadSongLabel = __('Upload song');




    player_inspector_controls = arr_options.map(function(el4){

      if(el4.name=='dzsap_meta_item_source' || el4.name=='source'|| el4.name=='item_source'){
        return '';
      }

      var args = {
          label: el4.title,
          value: props.attributes[el4.name] ? props.attributes[el4.name] : '',
          instanceId: el4.name,
          onChange: (value) => {props.setAttributes({[el4.name]:value});  }
          // onChange: (e,arg2) => {console.info(this, e,arg2); onValueChange(e,this)}
        }
      ;



      let Sidenote = null;

      if(el4.sidenote){
        Sidenote = (
          <div className="sidenote">{el4.sidenote}</div>
        )
      }




      if(el4.type=='text'){
        return (
          <div className="zoomsounds-inspector-setting type-text">
            <TextControl
              {...args}
            />
            {Sidenote}
          </div>
        )
          ;
      }
      if(el4.type=='select'){

        if(el4.choices && !(el4.options)){
          el4.options = el4.choices;
        }

        // delete args.instanceId ;

        // args.options = el4.options;
        // console.info('select args - ',args);
        // console.info('el4.options - ',el4.options);
        return (
          <SelectControl
            {...args}
            options={el4.options}
          />
        )
          ;
      }


      if(el4.type=='attach'){

        if(el4.upload_type){

          // args.type = el4.upload_type;
          args.allowedTypes=[el4.upload_type];
        }
        args.onChange = null;


        if(props.attributes[el4.name]){
          uploadSongLabel = __('Select another upload');
        }

        return (
          <div className="zoomsounds-inspector-setting type-attach">
            <label className="components-base-control__label" >{el4.title}</label>
            <MediaUpload
              {...args}
              onSelect={(imageObject) => { console.log('imageObject - ', imageObject); props.setAttributes( { [el4.name]: imageObject.url } ); console.info(' props - ',props); } }
              render = {({ open }) => (
                <div className="render-song-selector">
                  {props.attributes[el4.name]?(
                    <RichText
                      format="string"
                      formattingControls={ [] }
                      placeholder={ __( 'Input song name' ) }
                      onChange={ (val) => props.setAttributes({[el4.name]: val}) }
                      value={ props.attributes[el4.name] }
                    />
                  ):""}
                  <button className="button-secondary" onClick={open}>{ uploadButtonLabel }</button>
                </div>
              )}
            />
          </div>
        )
          ;
      }


    })
    // console.info('player_inspector_controls- ',player_inspector_controls);



    return [
      !! props.isSelected && (
        <InspectorControls key="inspector">
          {player_inspector_controls}
        </InspectorControls>
      ),
      <div className={ props.className }>
        <div className={ ( props.attributes.theme ? 'click-to-tweet-alt' : 'click-to-tweet' ) }>
          <div className="zoomsounds-containers">
            <h4>{ __( 'Zoomsounds Player' ) }</h4>
            <div className="react-setting-container">
              <div className="react-setting-container--label">{ __( 'Artist name' ) }</div>
              <div className="react-setting-container--control">
                <RichText
                  format="string"
                  formattingControls={ [] }
                  placeholder={ __( 'Input artist name' ) }
                  onChange={ onChangeTweet }
                  value={ props.attributes.artistname }
                />
              </div>
            </div>
            <div className="react-setting-container">
              <div className="react-setting-container--label">{ __( 'Song name' ) }</div>
              <div className="react-setting-container--control">
                <RichText
                  format="string"
                  formattingControls={ [] }
                  placeholder={ __( 'Input song name' ) }
                  onChange={ (val) => props.setAttributes({the_post_title: val}) }
                  value={ props.attributes.the_post_title }
                />
              </div>
            </div>
            <div className="react-setting-container">
              <div className="react-setting-container--label">{ __( 'Song source' ) }</div>
              <div className="react-setting-container--control">
                <MediaUpload
                  onSelect={(imageObject) => { console.log('imageObject - ', imageObject); props.setAttributes( { source: imageObject.url } ); props.setAttributes( { playerid: imageObject.id } );  console.info(' props - ',props); } }
                  allowedTypes={['audio']}
                  value={props.attributes.source} // make sure you destructured backgroundImage from props.attributes!
                  render={({ open }) => (
                    <div className="render-song-selector">
                      {props.attributes.source?(
                        <RichText
                          format="string"
                          formattingControls={ [] }
                          placeholder={ __( 'Input song name' ) }
                          onChange={ (val) => {props.setAttributes({source: val}); props.setAttributes( { playerid: '' } );}  }
                          value={ props.attributes.source }
                        />
                      ):""}
                      <button className="button-secondary" onClick={open}>{ uploadSongLabel }</button>
                    </div>
                  )}
                />
              </div>
            </div>

          </div>

          <p>
            <a className="ctt-btn">
              { props.attributes.button }
            </a>
          </p>
        </div>
      </div>
    ];
  },
  // Defining the front-end interface
  save() {
    // Rendering in PHP
    return null;
  },
});
