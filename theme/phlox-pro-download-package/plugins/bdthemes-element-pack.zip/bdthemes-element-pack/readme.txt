=== Element Pack ===
Contributors: bdthemes
Donate link: http://bdthemes.com/
Tags: elementor, element, pack, addon, bdthemes
Requires at least: 4.9.0
Tested up to: 5.2.1
Requires PHP: 5.6.0
Stable tag: 3.1.1
License: GPL3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Elementor requires at least: 2.3.0
Elementor tested up to: 2.5.14

Best Addon for Elementor WordPress Plugin with 110+ Most Popular Elements that need your everyday website page building.


== Description ==

Element Pack addon for Elementor has been developed with world’s best practice code standard and meets proper validation using the latest CSS, HTML5 and PHP 7.x technology to bring you a professional addon for Elementor Page Builder Plugin that is WordPress 4.9.x ready.

Element Pack for Elementor included most commonly used elements (which called widget) that help you to easily manage your website content simply drag and drop, seriously no programming knowledge required.

It’s also multilingual ready (more pre-made translation coming very soon).

 
== Installation ==
 
This section describes how to install the plugin and get it working.
 
e.g.
 
1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Start use it by go to elementor editor.

 
== Changelog ==
## 3.1.1 [1st June 2019]

### Fixed

- Custom gallery skin issue fixed
- Testimonial slider skin issue fixed

## 3.1.0 [1st June 2019]

### Added

- WPML Support added now all widget fully compatible with WPML
- Header and Footer builder added (Required Rooten theme 2.0+)
- Testimonial meta position change option added (Thanks to Gary Smith)
- IconNav icon color option added
- Marker icon now select any fontawesome icon (Thanks to Vion Zow)
- New licensing system added
- Audio player shortcode support added
- Slideshow widget text now you can set width separately (Thanks to Blerim Gajtani)

### Updated

- Custom gallery direct link option updated
- Template selection option now back for all template based widget

### Fixed

- Static date format issue fixed
- Marker caption issue fixed
- ACF issue for Custom carousel + Advanced Image Gallery fixed (Thanks to Soporte Gekkota)
- Chart widget float (0.00) value issue fixed (Thanks to Florian Fendt)
- editor.css RTL issue fixed
- Tooltip offset and distance issue fixed (Thanks to Rhym Zow)
- FAQ multi category filter issue fixed ()
- Now editor load more faster with all widgets + huge code re-factor + optimized
- advanced button style i issue fixed
- Carousel & Custom carousel widget tablet responsive issue fixed
- Custom gallery new tab issue fixed
- Some post widget static date issue fixed
- Default category not showing in overly in post gallery (Thanks to Blerim Gajtani)



## 3.0.11 [17th April 2019]

### Added

- Table of content regular layout added
- User login logged in custom text and custom register link option added

### Fixed

- Tabs mobile mode fullwidth not working for justfy align
- Tabs showing wrong control for bottom layout
- Table of content header missing in offcanvas layout
- Price list link pointer not showing
- WPForm pro version issue fixed
- Overall post query performance improved


## 3.0.10 [5th April 2019]

### Added

- Custom gallery now support thumbnail direct link 
- Advanced heading split space option added (Thanks to Alexandre Maciel)
- Advanced image gallery lightbox transition option added
- Post gallery lightbox transition option added
- Table of content index header option added

### Updated

- Improve widget javascript
- Update support & doc link
- Switcher control now more user friendly 

### Fixed

- Testimonial match height now set by default but you can change it from option
- Device slider dynamic content show issue fixed
- Toggle dynamic content show issue fixed
- Helpdesk style conflict issue fixed (Thanks to Alex Shram)
- Price list text area custom link issue fixed (Thanks to Yan Thiaudiere)
- Cookie consent Expiry Date issue fixed
- Carousel arrow responsive issue fixed
- Custom gallery condition issue fixed
- Device slider dynamic issue fixed (Thanks to Cengiz Karaman)
- HelpDesk tooltip issue fixed
- Price Table ribbon condition issue fixed
- Protected content login form issue fixed
- Tabs responsive issue fixed and full width nav option added for mobile (Thanks to Mohammad Rafi)
- Thumb gallery content condition issue fixed
- Twitter slider item background option added (because of fade transition)


## 3.0.9 [10th March 2019]

### Added

- Tabs now you can set sticky nav mode
- Price table heading tag change option added
- Section sticky issue fixed for inner section
- 

### Updated

- Section Sticky and Schedule content controls move to advanced tab

### Fixed

- Testmonial carousel, slider and grid 
- Open Street map on scroll map zoom issue fixed


## 3.0.8 [06th March 2019]

### Fixed

- Animated Heading php error issue fixed

## 3.0.7 [06th March 2019]

### Added

- Offcanvas custom link option added
- Testimonial Carousel match height option added
- Marker tooltip added more placement option 

### Fixed

- Elementor 2.5.0 compatibility issue fixed
- Animated Heading loading issue
- Weather API error issue fixed
- Tooltip script updated and fixed some minor issue
- Fix some widgets alter tag issue

### Removed

- element pack theme define removed for some speedup issue


## 3.0.6 [03rd March 2019]

### Added

- Weather Condition name option added
- Accordion and tabs widget hash location auto show option added
- Audio player loop option added (Thanks to Todd)
- Advanced Image Gallery Tilt scale option added

### Fixed

- Advanced image gallery hidden gallery text and style issue fixed (Thanks to Darryl)
- Advanced image gallery always overlay issue fixed
- Woocommerce Carousel image alter name fixed (Thanks to vperesyp)
- Image Compare border radius issue fixed (Thanks to Christian Holzner)
- Woocommerce Product Table script optimized
- Advanced icon box onclick event not working
- Scroll Button flickering issue fixed
- Tabs and accordion shortcode render issue fixed
- Admin settings name issue fixed
- Advanced heading rotate issue fixed
- Thumb gallery post reset issue fixed


## 3.0.5 [16th February 2019]

### Added

- Post slider skin vast and hazel now you can set post limit

### Updated

- 3rd Party widgets settings more understandable

### Fixed

- Dual Button onclick event issue fixed
- System info object bug issue fixed (Thanks to Xseam, huberu, creatifworks)
- Instagram widget CORS issue fixed
- Some widgets icon missing issue fixed
- Booked calendar widget on/off issue fixed
- Particle JS not defined some edge cases
- Iframe widget auto height not defined some edge cases
- Weather widget today layout icon not showing
- Fixed some performance issue


## 3.0.4 [13th February 2019]

### Fixed

- Panel slider spacing issue fixed (Thanks to Tommy Keller)
- Audio player Title typography issue fixed
- Audio player button issue fixed
- svg include error issue fixed


## 3.0.3 [12th February 2019]

### Added

- All widgets icons re-designed now more understandable for user

### Fixed

- Weather icon missing and some condition issue fixed (Thanks to Nathalie)
- Testimonial post loop issue fixed (Thanks to Alex Shram)
- Audio player skin and icon align issue fixed (Thanks to Ameel MD)
- Advanced Icon box readmore button condition issue fixed
- Post Grid paddle skin php error issue fixed (Thanks to Theuns Coetzee)


## 3.0.2 [1st February 2019]

### Added

- Iframe auto height option added

### Updated 

- Weather widget completely re-coded with new weather API
- Elementor/AE Template selector changed with text input (because it's slowdown all over element pack, we will add new search based template select option in new major update)
- UIKit updated to 3.0.3

### Fixed

- Post Slider text color fixed
- Open Street Map Empty Marker fixed
- Offcanvas widget do wrong behavior
- Icon Nav Offcanvas menu wrong behavior issue fixed
- Update checker php 7.3 issue fixed
- Minor style issue fixed for some widgets


## 3.0.1 [15th January 2019]

### Updated

- Elementor 2.4.0 compatibility tested
- UIKit Updated to 3.0.1
- Table of Content Button Hover Option Added
- Simple Contact Form Contact Number Added
- Post Block Featured Image Style Added
- Mailchimp Before Icon Added
- Dropbar Button Offset Added
- Price Table Margin, Shadow Added
- Panel Slider Script Optimize
- Table Script Optimize
- WC Carousel Script Optimize
- Post Slider Skin Hazel Right Part Color
- Login Widget Edit Profile Link Turn On/Off Added
- Particles javascript optimize for better loading
- Slideshow, WC Slider, Testimonial slider, Device slider, new ticker, post slider and thumb gallery widget more smooth touch behavior

### Fixed 

- Post Slider Skin Vast Image Cover Fix
- Offcanvas Close Button Dynamic
- Timeline Olivier Skin Responsive Fix
- Instagram Ovelay-Gap, Overlay Icon Size, Follow Me, Image CSS Filter Added
- Chart Type Doughnut Fixed
- Audio Player Player Volume Line Height Fixed
- Video Player Player Volume Line Height Fixed
- Timeline Animation Fixed

### Note

- Rooten theme update issue fixed, if you using this theme please update it.


## 3.0.0 [7th January 2019]

### Note

- If you want to upgrade version 2.x to 3.0 so you must keep a backup your website if you used modal widget because modal completely changed. If you upgrade it to version 3.0 your modal will be disappear and you should re-make it again. But if you can recover it by following this doc: https://bdthemes.com/support/knowledge/details/38/

### Added
- [Open Street Map](https://bdthemes.net/demo/wordpress/element-pack/element/open-street-map/) Widget added
- [Video Gallery](https://bdthemes.net/demo/wordpress/element-pack/element/video-gallery/) widget added
- [Help Desk](https://bdthemes.net/demo/wordpress/element-pack/element/help-desk/) widget added
- [Charts](https://bdthemes.net/demo/wordpress/element-pack/element/charts/) widget added
- [360 Degree Product Viewer](https://bdthemes.net/demo/wordpress/element-pack/element/360-product-viewer/) widget added
- [WooCommerce Slider](https://bdthemes.net/demo/wordpress/element-pack/element/woocommerce-slider/) widget added
- [Table of content](https://bdthemes.net/demo/wordpress/element-pack/table-of-content-test-post/) fully re-coded
- Modal widget completely re-coded and custom link option added
- Timeline widget compeletely re-coded added new skin
- Added some future prove stability for existing widgets [No more break like audio player, modal etc]

### Updated

- Image Magnifier widget script optimized
- Instagram widget script optimized
- Search widget default icon color option added
- Tabs widget automatic ID added in title
- Cookie consent widget script update + new push down option added for top position
- Custom carousel script optimized
- Carousel render option added for hidden elements (for example tabs/accordion etc)
- Toggle widget textarea change to Editor
- Profile link added for twitter avatar in twitter carousel + slider widget
- Cookie consent widget script update + new pushdown option added
- Device Slider widget title link added
- Testimonial slider and carousel script optimized
- Twitter slider and carousel script optimized

### Fixed

- Audio player minor style issue fixed
- All Carousel mobile arrow issue fixed
- Lightbox widget dynamic issue fixed
- Post slider height issue fixed
- Testimonial slider responsive issue fixed and image resize option added
- Advanced Heading Gradient and image issue fixed for Firefox/EDGE
- Post gallery excerpt issue fixed
- Weather widget script issue fixed


### Removed

- Weather widget yahoo provider removed [because yahoo shutdown his weather api]

### Language

- All language string added in pot file


## 2.6.5 [09 December 2018]

### Added

- Advanced Icon Box Onclick Javascript event option added

### Fixed

- Post list margin issue fixed for astra theme
- Scroll image background cover issue fixed for image framing
- Carousel transition duration issue fixed
- Dual button separated radius issue fixed
- Call out center layout overflow issue fixed

### Updated

- Responsive option added for content spacing in FAQ widget
- Carousel arrow and dots position now can control responsive
- All grid filter update with more customization option
- Advanced Image gallery always show caption now more optimized


## 2.6.4 [07 December 2018]

### Added

- Properly Checked and add support for WordPress 5.0
- Advanced Image Gallery always caption show option added
- Simple Contact form optional contact email option added in settings
- Device slider kenburn option added
- Dual button separated radius option added
- Global tooltip edit option added in page setting
- Price Table tooltip option added for feature list
- Scroll Image frame option added
- Custom Content skin added in custom carousel widget


### Updated

- Advanced Heading text shadow option added for main heading
- Carousel and Slider widget script loading optimized
- FAQ bottom space & space between responsive added
- Marker bg now can add gradient color and image
- Post list thumbnail styles added
- Scroll Nav tooltip updated
- In Search widget toogle icon size + icon change option added
- Tab widget Contact spacing and Tab spacing now control in responsive
- Testimonial Slider/Carousel default thumbnail added
- Slideshow and Thumb Gallery reverse kenburn option added
- Woo Product Grid filter option added


### Fixed

- Advanced Icon Box read more show hide issue fixed
- Carousel default image issue fixed
- Simple Contact form Reply-to issue fixed
- Contact Form 7 Space between issue fixed
- Flipbox and Price List Elementor 2.3.4 compatiblity issue fixed
- Ninja form color and bg issue fixed
- Post block margin issue fixed
- Post grid limit issue fixed
- Post grid tab title color, margin and typography fixed
- Post slider high resolution image align and Kenburn issue fixed
- Register widget php error fixed
- Image Magnifier image select option fixed

### Language 

- Main po language file updated


## 2.6.3 [16 November 2018]

### Added

- Post Grid widget reverse skin added
- Simple Contact Form widget reCAPTCHA option added
- Single post excerpt option added
- Now you can select/deselect all widget in element pack settings
- Slider and Post Slider widget kenburn effect added
- News ticker widget height control and date option added
- Lightbox widget lightbox style option added in page settings
- Iframe widget sandbox and scrollbar option added
- Sticky Section active shadow option added
- Tiny layout added in weather widget
- Scroll nav content offset option added

### Fixed

- Post gallery tags filter not filtered correctly
- Post excerpt format all universal way
- Carousel item gap option fixed
- Mailchimp input width issue fixed
- Widget tooltip id issue fixed
- User register dropdown skin and event countdown skin php 7.1 error fixed
- Thumb gallery, post list, post slider, post grid, post card, post block modern, post gallery, carousel etc image placeholder fixed
- Item gap problem fixed for carousel skin alice
- Fix wrong alert for api key in advanced google map widget
- Audio and Video player dynamic URL issue fixed
- Fixed User register conflict with default registration
- Timeline custom skin icon issue fixed
- Some widgets script improved for jQuery load in footer

### Updated

- Post card query changed, now you can select any post type
- Mailchimp widget input field fullwidth problem fixed
- Main Heading now you can split and add separated style in advanced heading

### Changed

- Audio player URL structrue changed, now you can select hosted audio easily
- Custom Carousel lighbox style moved to page settings for globally style all lightbox
- Protected content widget completely re-code for more flexible usage
- Iframe widget controls re-arranged for better user experience


### Removed 

- Progress pie delay and steps control removed

### Language

- Edit profile language string missing fixed
- Main po language file updated

### Note

- You need to select your audio source again because of some core changes (We are sorry for this issue)
- Protected content widget page maybe you need to re save (We are sorry for this issue)


## 2.6.2 [28 October 2018]

### Fixed

- Element Pack Site Minified Javascript issue fixed
- Fix height of Masonry Grid
- Fix Sticky hiding with Offcanvas in overlay mode
- Fix Parallax in combination with Offcanvas in overlay mode
- Post gallery category color not changing issue fixed


## 2.6.1 [28 October 2018]
	
### Added

- Advanced icon box advanced radius option added
- Post block featured item height option added
- Icon link on hover option added in Scroll Image
- Single post widget excerpt option added
- Trailer box text spacing option added

### Fixed

- Register widget conflict with some theme
- Business hour widget width issue fixed
- Circle menu jQuery loading issue fixed
- Custom gallery height issue fixed
- Icon nav script updated for speed up workflow
- Post gallery category style fixed
- Protected content message option issue fixed
- QRcode widget jQuery loading issue fixed
- WC Product exclude option multiple product issue fixed
- New widgets on/off issue fixed in settings page

### Updated

- Elementor extended options added [EP] tag for better understand
- Marker tooltip control more organize
- Panel slider slide image align updated

### Removed

- Iframe has wrong control that removed

### Language 

- Language file updated
- Element Pack name now intake with english name


## 2.6.0 [22 October 2018]
	
### Added

- [Protected Content](https://bdthemes.net/demo/wordpress/element-pack/elements/protected-content/) Widget Added
- [Advanced Icon Box](https://bdthemes.net/demo/wordpress/element-pack/elements/advanced-icon-box/) Widget Added
- [Iframe](https://bdthemes.net/demo/wordpress/element-pack/elements/iframe/) Widget added
- [Advanced Image Gallery](https://bdthemes.net/demo/wordpress/element-pack/elements/advanced-image-gallery/) Carousel skin added
- [Post Grid](https://bdthemes.net/demo/wordpress/element-pack/elements/post-grid/) Widget Harold skin added
- Icon nav widget icon bottom text option added
- Panel Slider global item link option added
- Scroll Image Widget badge option added
- WC Product skin exclude product option added
- Dom functions support selectors
- Advanced Google map api key warning added
- Pause on hover option added in carousel, [wc carousel](https://bdthemes.net/demo/wordpress/element-pack/elements/woocommerce-products/), testimonial carousel, custom carousel, slider, twitter carousel widget
- Dual button separated box shadow option added
- Image compare widget few new option added
- User Login dropdown skin width option added

### Updated

- Marker tooltip position now can set individually
- Post block now you can select any post type
- Table of content button now set anywhere + can re-position for table and mobile device
- Panel slider height issue updated + image size option added

### Fixed

- Thumb gallery custom skin button style issue fixed
- Testimonial Slider Single skin arrow issue fixed
- Progress pie duplicate issue fixed
- Instagram loading issue fixed when jQuery loaded in footer
- control name conflict issue fixed for some edge cases
- Dual button editor template issue fixed
- Simple contact form submit button align issue fixed
- Custom gallery lightbox next issue fixed
- Parallax section wrong opacity value issue fixed
- Image compare widget editor load, duplicate issue fixed
- Image Magnifier widget editor load, duplicate issue fixed
- Instagram widget editor load, duplicate issue fixed
- Preserve color not working if class is set on internally used svg icons
- Close color being overwritten from toolbar in Lightbox component
- Modal not hiding upon being destroyed
- Using node as offset in position mixin
- Using Height Match component on elements with different offsetParents
- Rounding error in Height Match component
- Sticky placeholder height on resize
- Starting/stopping of autoplay in Lightbox
- Initially wrong position of background image in Parallax component
- Calling `isActive` on `undefined` in Navbar component
- Fix `isInView` function for elements with zero width and height
- Support Expired license invalid issue fixed

### Changed

- Advanced image gallery layout changed to skin
- Viewport Height component no longer sets a `height` except for IE
- Viewport Height component no longer forces `box-sizing: border-box`
- Improve Tooltip performance
- Improve Parallax performance
- Improve Sticky performance
- Rename `selModal` to `selContainer` and `selPanel` to `selContent` in Overflow Auto component

### Removed

- Remove `::-moz-selection` which is not needed anymore
- Remove component `init` hook
- Remove component `ready` hook


### Language

- Main language file updated
- Some missing language string translated properly


## 2.5.5 [30 September 2018]

### Added
	
- Testimonial Single Skin added
- Panel Slider Middle Skin added
- User login widget logged in user details + custom menu option added
- WooCommerce Carousel category selection and align option added
- Tabs widget subtitle option added
- Post grid pagination option added
- Search widget icon size option added

### Updated

- WooCommerce Product table huge improvement done
- Custom carousel more improved and responsive break point now work from elementor settings and lightbox color option now fixed
- Carousel, Wc Carousel, Twitter Carousel, Panel Slider and Testimonials Carousel responsive break point now work from elementor settings
- Progress pie now animate when it is come in viewport
- Table of content now responsive friendly
- Timeline widget now more animated
- Weather widget now select open weather map or yahoo weather data

### Fixed

- Particles js loading issue fixed
- FAQ excerpt issue fixed
- Gravity form error message, radio and checkbox style fixed
- Advanced heading default origin set to top-left
- Post gallery pagination style now more improved
- Post Grid tab widget loading issue fixed
- Slider autoplay and loop issue fixed
- Table widget search, pagination etc style issue fixed

### Note

- If you use custom carousel, thumb gallery, weather, WC product (table or default skin)  widgets in your any page so please go to that page and re-save the page, because those widget some settings changed



## 2.5.4 [11 September 2018]

### Added

- [Widget Tooltip](https://bdthemes.net/demo/wordpress/element-pack/elements/widget-tooltip/) options added for all widget
- Carousel skin alice added and vertical layout moved to skin vertical
- WooCommerce product table category and tag option added
- WooCommerce product table thumbnail lightbox option added
- Panel slider skew option added
- FAQ widget excerpt limit and readmore button added

### Updated

- All widget code improved and more reliable
- IconNav widget tooltip updated with more option
- Marker tooltip updated with more features
- Add more margin between accordion title and icon
- Ribbon now rotate, set x offset and padding

### Fixed

- Registration notification email issue fixed
- Timeline icon size bug fixed for custom skin
- Fix form placeholder color in Edge
- Fix accordion icon position if title is wrapping into the next line
- Fix Slider incorrectly showing navigation
- Fix element queuing in Scrollspy component
- Fix parallax translating to subpixels
- Fix SVGs not preserving their aspect ratio in IE11
- Fix lazy loading images in Edge

### Removed

- Remove fix for uppercase SVGs attributes in Edge on Windows 10 older than build 16251



## 2.5.3 [21 August 2018]

### Added

- [Testimonial Slider](https://bdthemes.net/demo/wordpress/element-pack/elements/testimonial-slider/) widget added Thumb skin
- [Post Gallery](https://bdthemes.net/demo/wordpress/element-pack/elements/post-gallery/) widget added Trosia skin
- [Post Grid](https://bdthemes.net/demo/wordpress/element-pack/elements/post-grid/) widget added Trosia skin
- Carousel Center slide option added

### Updated

- UIKit framework updated to latest version

### Fixed

- Custom carousel autoplay bug fixed
- Countdown safari bug fixed
- Device slider youtube video loop issue fixed
- Post Gallery and Advanced Image Gallery masonry bottom gap bug fixed
- Hidden gallery lightbox bug fixed
- Post Galery Fedara and Abetis skin lightbox bug fixed
	

## 2.5.2 [4th August 2018]

### Added

- [Image Magnify](https://bdthemes.net/demo/wordpress/element-pack/elements/image-magnifier/) widget added
- WooCommerce table skin added in [wc product](https://bdthemes.net/demo/wordpress/element-pack/elements/woocommerce-products/) widget
- Advanced Button attention animation option added
- Call out button attention animation added
- Scroll Button fixed position option added
- Trailer box zoom effect option added
- Testimonial Carousel category option added
- Post grid thumbnail size added
- Post card thumbnail size added
- Post block modern thumbnail size added]
- Slideshow thumbnav opacity added

### Updated

- Simple contact form now name and email can half width
- Post gallery tilt effect now more realistic
- WooCommerce Product widget completely re-write with more options and fixed loading issue
- Custom Gallery now you can select video, youtube, vimeo, google map, website as lightbox link

### Fixed

- WC Carousel badge style bug fixed
- Register dropdown and modal button wrong text fixed
- Custom Gallery lightbox bug fixed
- User register icon spacing bug fixed
- Testimonials slider quotation icon now set typography
- Carousel vertical layout padding bug and item hover bg issue fixed
- Advanced image gallery now support dynamic post gallery

	
## 2.5.1 [23 July 2018]

### Updated

- Member widget alternative image option added

### Fixed

- User register php 7.2 issue fixed
- Navbar widget WPML Language menu issue fixed


## 2.5.0 [22 July 2018]

### Added

- [User Registration](https://bdthemes.net/demo/wordpress/element-pack/elements/user-register/) Widget added
- [Twitter Slider](https://bdthemes.net/demo/wordpress/element-pack/elements/twitter-slider/) widget added
- [WooCommerce Product Carousel](https://bdthemes.net/demo/wordpress/element-pack/elements/woocommerce-carousel/) Widget added
- [Simple Contact Form](https://bdthemes.net/demo/wordpress/element-pack/elements/simple-contact-form/) Widget added
- Advanced Heading gradient and main heading style added
- Scroll nav style option added
- Scroll Image widget external link option added
- Post Gallery excerpt and pagination option added
- Trailer box tilt and zoom option added

### Updated

- Post, Twitter, Custom Instagram, Testimonials Carousel shadow option added
- Gradient, Image, Main Heading Style added in Advanced Heading
- Autoplay fix in all Carousel and Slider
- Shadow style improve in all type of carousel widget
- Scroll to bottom option added in Slider and Slideshow Widget

### Changed

- Image Gallery, Scroll Image, Marker widget default lightbox changed

### Fixed

- Testimonial Slider, Carousel and Grid thumbnail show/hide issue fixed
- Testimonial rating align issue fixed when thumb off
- Carousel Vertical layout responsive issue fixed


## 2.4.1 [4th July 2018]


### Added

- [Testimonials grid widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/testimonial-grid/) 

### Fixed

- Base typography broken issue fixed


## 2.4.0 [4th July 2018]

### Added

- [Post Grid Tab Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/post-grid-tab/)
- [Dual Button widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/dual-button/)
- [Instagram Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/instagram/)
- [Table of Content Widget added](https://bdthemes.net/demo/wordpress/element-pack/table-of-content-test-post/)
- [Add to Cart Woocommerce single button widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/woocommerce-add-to-cart/) 
- Elementor 2.1 compatibility added

### Updated

- Table press responsive option added
- Advanced button 3 new effect added
- Post Grid style updated
- UIKit framework updated to latest version

### Fixed

- Comment disqus and facebook script now load async
- Version wrong number fixed
- Device slider style issue fixed
- Tabs title html escape removed
- Testimonial Carousel + Slider arrow and mobile style issue fixed
- Gravity Form show/hide title and ajax load switch fixed


## 2.3.0 [15 June 2018]

### Added

- [Post list widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/post-list/)
- [Post Grid Carmie Skin added](https://bdthemes.net/demo/wordpress/element-pack/elements/post-grid/)

### Updated

- Gravity form title and description show/hide option added
- Advanced Image Gallery Thumbnail option added for hidden gallery
- Advanced Image Gallery now added standalone lightbox
- Active padding option added in elementor section sticky
- Post Grid now support Custom Post Type
- Post Gallery now added standalone lightbox
- Thumb Gallery button typography added
- Post slider pagination typography added
- Circle menu icon size issue fixed
- Advanced Image Gallery, Animated Heading, Audio Player, Video Player, Circle Menu, Cookie Consent, Device slider, Flip Box, Icon Nav, Image Compare, Lightbox, 	Member, Price List, Progress Pie, QRCode, Scroll Image, Switcher Add some dynamic field.

###	Fixed

- Lightbox google map source fixed
- event calender countdown widget php 7 error fixed

## 2.2.0 [6 June 2018]

### Added

- [Easy Digital Download Download View Widget Added](https://bdthemes.net/demo/wordpress/element-pack/elements/easy-digital-downloads/)
- [Easy Digital Download Download History WIdget Added](https://bdthemes.net/demo/wordpress/element-pack/elements/easy-digital-downloads-history/)
- [Easy Digital Download Purchase History WIdget Added](https://bdthemes.net/demo/wordpress/element-pack/elements/easy-digital-downloads-purchase-history/)
- [Easy Digital Download Profile Widget Added](https://bdthemes.net/demo/wordpress/element-pack/elements/easy-download-portfolio-editor/)
- [BuddyPress Member Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/buddypress-member/)
- [BuddyPress Friends Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/buddypress-friends/)
- [BuddyPress Group Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/buddypress-group/)
- [Business Hour Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/business-hours/)
- [TablePress Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/business-hours/)
- [Lightbox Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/lightbox/)
- [Single Post Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/single-post/)
- [Cookie Consent Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/cookie-consent/)
- [Pricing Table Button integrate The Easy Digital Download](https://bdthemes.net/demo/wordpress/element-pack/elements/pricing-table/)

### Updated

- UIKit Framework updated to latest version

## 2.1.0 [21 May 2018]

### Added

- [Twitter Carousel Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/testimonial-carousel/)
- [Circle Menu Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/circle-menu/)
- [Scroll Image Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/scroll-image/)

### Updated

- Slideshow widget arrows and dots and thumbnav now position 7 places
- Testimonial Carousel arrows and dots now position 7 places
- Testimonial Slider arrows and dots now position 7 places
- UIKit updated to latest version
- Section Sticky active background color added
- Post gallery Grid, Filter, Masonry and Gap Settings re-coded for better usablity + optimized code and script.
- Advanced Heading Offset and Rotate option now work on tablet and mobile
- Offcanvas vw width added instead of % width

### Fixed

- Carousel thumb resize was not working
- License key error some edge cases
- Post gallery icon missing fixed
- Post slider button hover color bug fixed
- Post block skin was missing


## 2.0.4

### Updated

- Modal splash screen & exit popup bug for some edge cases

### Fixed

- Custom carousel widget arrows and dots now position 7 places


## 2.0.3 [11th May 2018]

### Fixed

- Advanced Image gallery height bug for some edge cases
- Custom gallery height bug for some edge cases
	

## 2.0.2

### Updated

- Modal content typography added

### Fixed

- Modal custom content shortcode not executed properly
- Advanced Heading not showing bug fixed


## 2.0.1 [9th May 2018]

### Added

- [Carousel widget arrows and dots now position 7 places](https://bdthemes.net/demo/wordpress/element-pack/elements/carousel/)

### Updated

- Offcanvas % width added
- Timeline Left, Right align option added

### Fixed

- wpDataTables css issue fixed
- Switcher widget AE Template and Elementor Template mismatch fixed.


## 2.0.0 [6th May 2018]

### Added

- [Audio Player Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/audio-player/)
- [Video Player Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/video-player/)
- [Weather Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/weather/)
- [Table Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/table/)
- [FAQ Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/faq/)
- [Pricing table 7 Layout + Partait Skin added](https://bdthemes.net/demo/wordpress/element-pack/elements/pricing-table/)
- [Member Widget Partait Skin Added](https://bdthemes.net/demo/wordpress/element-pack/elements/member/)
- Dynamic option added which widget possible to apply (This features available who are using elementor pro version)
- All widget now added EP badge for find out easily

### Updated

- Modal widget splash screen + exit popup options added and all control reorganized.
- Offcanvas responsive width control added
- Editor now added EP badge and hover blue color for all widget to identify easily
- Carousel Vertical layout added

### Fixed

- Gravity Form style issue fixed in edit mode
- Offcanvas and Icon Nav offcanvas style conflict fixed
- Parallax script loading fixed when parallax not used
- Updater class php 7 error fixed
- Advanced heading php error fixed
- User login dropdown skin widget php error fixed
- Animated heading widget php error fixed
- Parallax background widget php error fixed



## 1.12.0 [19th April 2018]

### Added

- [Icon Navigation Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/icon-nav/)
- [Gravity Form Widget Added](https://bdthemes.net/demo/wordpress/element-pack/elements/gravity-forms/)
- [Ninja Form Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/ninja-forms/)
- [Caldera Form Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/caldera-form/)
- [Parallax Option added in section](https://bdthemes.net/demo/wordpress/element-pack/elements/parallax-section/)
- [Comment Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/comment/)

### Updated

- Woocommerce category more refined
- Advanced Button editing now super fast
- Accordion Anywhere Elementor and Elementor Template source selection added
- Tabs Anywhere Elementor and Elementor Template source selection added
- Dropbar Anywhere Elementor and Elementor Template source selection added
- Member social icon bg color + padding option added
- UIKit framework updated to latest version

### Fixed

- Marker zoom and tooltip issue fixed and animation radius now work with radius
- Core code more optimized
- Slider RTL issue fixed

### Language

- Polish [PL] Language added


## 1.11.0 [06 April 2018]

### Added

- [Advanced Button Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/advanced-button/)
- [Post Grid Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/post-grid/)
- [Toggle Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/toggle/)
- [Switcher Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/switcher/)
- [QuForm Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/quform/)
- Licensing system added [Please use your purchase key to get update automatically

### Updated

- Woocommerce Category column gap option added
- Offcanvas now select elementor template and anywhere elementor template alternative of sidebar.

### Removed

- Woocommerce Category margin removed

### Fixed

- Navbar php 7 warning fixed
- Advanced Image Gallery Hidden layout animation fixed
- Modal fullscreen height fixed, fullscreen flickr issue fixed and default background color added
- Custom carousel icon issue fixed, video icons now works properly, coverflow animation fixed
- Social share icon editor issue fixed
- Google map missing api key issue fixed
- Advanced image gallery button animation fixed
- Post Slider and Vast Skin excerpt show issue fixed
- Some widget css style improved
- Booked Calendar member only option fixed

### Language

- Language Updated and [CZ, ID, MY, NL, BR, ZH] languages added
	

## 1.10.0 [27 March 2018]

### Added

- [Search Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/search/)
- [Device Slider Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/device-slider/)
- [Booked Calendar Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/booked-calendar/)
- [Layer Slider Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/layer-slider/)
- [bbPress Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/bbpress/)
- [Download Monitor Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/download-monitor/)
- [Post Slider Vast Skin added](https://bdthemes.net/demo/wordpress/element-pack/elements/post-slider/)
- [Custom Timeline Skin Added](https://bdthemes.net/demo/wordpress/element-pack/elements/timeline/)
- [Animated Heading Typed Layout added](https://bdthemes.net/demo/wordpress/element-pack/elements/animated-heading/)
- [Testimonials Carousel Vyxo Skin Added](https://bdthemes.net/demo/wordpress/element-pack/elements/testimonial-carousel/)

### Updated

- Slideshow thumb nav option added
- Navbar and Offcanvas menu offset option added for matching column gap
- Advanced Image Gallery, Post Gallery and Custom Gallery Widget tilt effect added
- HOT and NEW badge added by css class in Navbar widget
- Advanced image gallery widget icon now can resize

### Fixed

- Revolution slider alias issue fixed
- Thumb Gallery mobile size fullscreen issue fixed
- Post gallery filter bug fixed

### Language

- Language file added [DE, ES, FR, HE, IT, JP, RU, HK]
- Language file updated.


## 1.9.0 [17 March 2018]

### Added

- [Advanced Image Gallery Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/advanced-image-gallery/)
- [Navbar Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/navbar/)
- [Accordion Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/accordion/)
- [Tabs Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/tabs/)
- [Timeline Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/timeline/)
- [WP Forms Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/wp-forms/)
- [Section Sticky Options added](https://bdthemes.net/demo/wordpress/element-pack/sticky-section/)
- [Thumb Gallery Widget Custom Content Skin added + Content Transition option added](https://bdthemes.net/demo/wordpress/element-pack/elements/thumb-gallery/)

### Updated

- Carousel Thumbnail linked
- Countdown Widget now align 2 way
- QR Code Widget now set own page url automatically and can align properly
- Custom Gallery Masonry option added

### Fixed

- Post Gallery Widget masonry fixed
- Event Calendar Countdown Skin alignment issue fixed
- Flipbox Widget button size issue fixed
- 3rd Party Widget ON/OFF options fixed
- Many small bug fixed + css style improved

### Language

- Language file updated.


## 1.8.0 [05 March 2018]

### Added

- [Advanced Google Map Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/advanced-google-map/)
- [QR Code Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/qr-code/)
- [Flip Box Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/flip-box/)
- [Post Gallery Fedara, Abetis Skin added](https://bdthemes.net/demo/wordpress/element-pack/elements/post-gallery/)
- [Custom Gallery Fedara, Abetis Skin added](https://bdthemes.net/demo/wordpress/element-pack/elements/custom-gallery/)
- [Event Calendar Post Countdown added in Countdown Widget](https://bdthemes.net/demo/wordpress/element-pack/elements/event-calendar-countdown/)
- [Offcanvas Button align + size option added](https://bdthemes.net/demo/wordpress/element-pack/elements/offcanvas/)
- [Member Widget Calm Skin added](https://bdthemes.net/demo/wordpress/element-pack/elements/member/)
- [Dropbar Widget align + size option added](https://bdthemes.net/demo/wordpress/element-pack/elements/dropbar/)
- Widget ON/OFF option added in settings sage
- 3rd Party Widget ON/OFF option added in setting page
- Elementor Extended option ON/OFF added in setting page

### Changed

- Carousel Widget now more flexible for color change

### Fixed

- All CSS re-factor and removed some unnecessary css, separated rarely used css. [old was 490KB now 233KB]
- Drop first load dropbar show fixed
- Many more css and javascript optimized
- Testimonials Slider Rating color fixed
- Modal widget full widget mode content style now accessible

	
## 1.7.0 [21 February 2018]

### Added

- [User Login Widget added with 3 skin [Normal + Dropdown + Modal]](https://bdthemes.net/demo/wordpress/element-pack/elements/user-login/)
- [Modal widget button align, size, Content overflow scroll option added and improve the edit speed.](https://bdthemes.net/demo/wordpress/element-pack/elements/modal/)
- [Member widget Phaedra skin added](https://bdthemes.net/demo/wordpress/element-pack/elements/member/)
- [Testimonial Carousel widget twyla skin added](https://bdthemes.net/demo/wordpress/element-pack/elements/testimonial-carousel/)

### Updated

- UIKit framework updated to latest version + UIKit icons added.
- Marker widget now more interactive
- Modal button now can align properly
- Custom Gallery Lightbox icon re-arrange for better ux

### Language

- Language file updated


## 1.6.0 [14 February 2018]

### Added

- [Advanced Heading widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/advanced-heading/)
- [News Ticker widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/news-ticker/)
- Plugin Auto Updater function added
- Scheduled Section option added in section option
- New Business Page added
- 2 Agency Homepage added
- Watch Shop Homepage added

### Updated

- Scroll nav widget responsive improved
- Slideshow Widget title now support html tag
- Slider Widget title now support html tag

### Fixed
	
- Box shadow option fix for call out widget
- Custom Gallery Mobile size overlap bug fixed
- Slider widget button hover color fixed
- Post slider language translation issue fixed


## 1.5.1 [06 February 2018]

### Added

- Business plan, Online Course, Event Management Demo Content added

### Fixed	
- Single Widget save issue fixed

### Removed 	
- Remove some unnecessary code and files
	

## 1.5.0 [06 February 2018]

### Added

- [Custom Gallery widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/custom-gallery/)
- [Dropbar widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/dropbar/)
- [Thumb Gallery widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/thumb-gallery/)
- [Scroll Nav widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/scrollnav/)
- [Section Particles option added [element built-in section]](https://bdthemes.net/demo/wordpress/element-pack/elements/section-particles/)
- [Element Parallax for all widget [even all built-in widget]](https://bdthemes.net/demo/wordpress/element-pack/elements/element-parallax/)
- [Section Background Parallax [elementor built-in section]](https://bdthemes.net/demo/wordpress/element-pack/elements/parallax-background/)

### Updated

- Update UIKit framework
- Fix some widget style issue

### Fixed

- Post Gallery fix some color issue
- Post block read more style issue fixed
- Pricing list vertical align issue fixed
- Slideshow read more button icon align issue fixed


## 1.4.0 [26 January 2018]

### Added

- [Post Gallery Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/post-gallery/)
- [Animated Heading Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/animated-heading/)
- [Post block added 2 Extra Skin](https://bdthemes.net/demo/wordpress/element-pack/elements/post-block/)
- [Slideshow added fullscreen option](https://bdthemes.net/demo/wordpress/element-pack/elements/slideshow/)

### Updated

- Many internal function improve for better performance

### Fixed	
- Testimonial carousel widget fixed some styling issue
- Pricing list widget Pricing title + text gap fixed
- Woocommerce single product select option fixed
- Slideshow widget fixed some styling issue
- Testimonial slider widget fixed some styling issue

### Removed

- Woocommerce Custom product select option removed (we will add another custom product select widget)
	

## 1.3.0 [17 January 2018]

### Added

- [Custom Carousel Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/custom-carousel/)
- [Post Block Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/post-block/)
- [Post Slider Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/post-slider/)

### Updated	

- Minor Improve Call out Widget
- Multiple instance color and style issue fixed for Modal
- Multiple instance color and style issue fixed for Offcanvas
- Minor Improve Slideshow widget
- UIKit framework updated

## 1.2.0 [12th January 2018]

### Added

- [SlideShow Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/slideshow/)
- [Offcanvas Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/offcanvas/)
- [Social Share Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/social-share/)
- [Scroll Button Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/scroll-button/)

### Updated

- Minor Improve Progress Pie
- Minor Improve Slider
- Minor Improve Trailer box
- Minor Improve Image Compare

### Language
	
- Update Language File

## 1.1.0 [5th January 2018]


### Added

- [CountDown Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/countdown/)
- [Carousel Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/carousel/)
- [Member Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/member/)
- [Marker Widget added](https://bdthemes.net/demo/wordpress/element-pack/elements/marker/)

### Updated

- Minor improvement in Post Card
- Minor improvement in Testimonials Carousel
- Minor improvement in Post Block Modern
- Minor improvement in Slider

## 1.0.0
- Initial Release